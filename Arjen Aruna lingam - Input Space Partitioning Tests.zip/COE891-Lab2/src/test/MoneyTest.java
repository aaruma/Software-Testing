package test;
import main.IMoney;
import main.Money;
import junit.framework.TestCase;

/**
 * This is a trivial test which only tests the Money class.
 * If you modify the MoneyBag class, and run Clover with optimization, this test will not be run.
 */
public class MoneyTest extends TestCase {	
    public void testAdd() throws InterruptedException {
        Money tenEuro = new Money(10, "EURO");
        assertEquals(10, tenEuro.amount());
        assertEquals("EURO", tenEuro.currency());
        System.out.println("Tests taking too long? Try Clover's test optimization.");
        Thread.sleep(3000);
    }
    
	public void testAdd1() throws InterruptedException {
        Money tenEuro = new Money(0, "EURO");
        assertEquals(false, tenEuro.equals("EURO"));
        assertEquals("EURO", tenEuro.currency());
        System.out.println("Tests taking too long? Try Clover's test optimization.");
        Thread.sleep(3000);
    }
    
	public void testAdd2() throws InterruptedException {
		IMoney zero_EuroCopy = new Money(1, "EURO");
		Money tenEuro = new Money(10, "EURO");
		assertFalse(zero_EuroCopy.equals(tenEuro));
	}
	
	public void testAdd3() throws InterruptedException {
        Money zero_Euro = new Money(0, "EURO");
        IMoney one_Euro = new Money(1, "EURO");
        assertEquals(false, zero_Euro.equals(0));
        assertEquals("EURO", zero_Euro.currency());
        assertFalse(zero_Euro.equals(one_Euro));
        System.out.println("Tests taking too long? Try Clover's test optimization.");
        Thread.sleep(3000);
    }
	
	public void testNotEquals() {
        Money zero_Euro = new Money(0, "EURO");
        IMoney one_Euro = new Money(1, "EURO");
        assertFalse(zero_Euro.equals(one_Euro));
    }
    
    public void testInvalidEquals() throws InterruptedException {
        Money zero_Euro = new Money(0, "EURO");
        assertFalse(zero_Euro.equals(5));        
    }
    
    public void testCurrency() {
        Money zero_Euro = new Money(5, "EURO");
        assertEquals("EURO", zero_Euro.currency());
    }
}
