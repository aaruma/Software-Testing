package test;

import static org.junit.Assert.*;
import main.q2coverage;

import org.junit.Before;
import org.junit.Test;

public class q2coverageTest {
	q2coverage val;
	
	@Before
	public void initialize () {
		val = new q2coverage();
	}
	@Test
	public void testABFunc () {
		assertEquals(1, val.func(2, 3));
	}
	@Test
	public void testBAFunc () {
		assertEquals(1, val.func(3, 2));
	}
	@Test
	public void testEqualFunc () {
		assertEquals(0, val.func(2, 2));
	}
}
