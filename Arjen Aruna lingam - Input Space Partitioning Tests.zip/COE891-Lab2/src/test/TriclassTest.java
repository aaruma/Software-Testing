package test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import main.Triclass;

public class TriclassTest {

    @BeforeClass
    public static void start() {
        System.out.println("Testing started");
    }
    @AfterClass
    public static void complete() {
        System.out.println("Testing is finished");
    }
    @Test
    public void test() {
        System.out.println("Test 1 started");
        assertEquals("Isosceles", Triclass.classify(5, 5, 6));
        assertEquals("Isosceles", Triclass.classify(5, 5, 4));
        System.out.println("Test 1 finished");
    }
    @Test
    public void ScaleneTest() {
        System.out.println("Test 2 started");
        assertEquals("Scalene", Triclass.classify(2, 3, 4));
        assertEquals("Scalene", Triclass.classify(6, 5, 4));
        System.out.println("Test 2 finished");
    }
    @Test
    public void EquilateralTest() {
        System.out.println("Test 3 started");
        assertNotEquals("Equilateral", Triclass.classify(5, 5, 3));
        assertEquals("Equilateral", Triclass.classify(5, 5, 5));
        System.out.println("Test 3 finished");
    }
    @Test
    public void InvalidTest() {
        System.out.println("Test 4 started");
        assertEquals("Invalid", Triclass.classify(1, 1, 9));
        assertEquals("Invalid", Triclass.classify(1, 1, 8));
        System.out.println("Test 4 finished");
    }
    
    @Test
    public void negativeTest() {
        System.out.println("Test 5 started");
        assertEquals("Invalid", Triclass.classify(-1, -1, -9));
        assertEquals("Invalid", Triclass.classify(-1, -1, -8));
        System.out.println("Test 5 finished");
    }
}




