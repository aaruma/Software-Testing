package main;
public class Triclass {
	public static String classify(int x, int y, int z){
		System.out.println("X: " + x + ", Y: " + y + ", Z: " + z);
		// Range from 1 to 10
		if ((x > 0 && x <= 10) && (y > 0 && y <= 10) && (z > 0 && z <= 10)) {
			//	Inequalities
			if ((x + y > z) && (y + z > x) && (x + z > y)){
				if ((x == y) && (y == z)){
					return "Equilateral";
				}
				else if ((x ==y) || (y == z) || (x ==z)){
					return "Isosceles";
				}
				else{
					return "Scalene";
				}
			}
			else{
				return "Invalid";
			}
		}
		else{
			return "Invalid";
		}
	}
}
