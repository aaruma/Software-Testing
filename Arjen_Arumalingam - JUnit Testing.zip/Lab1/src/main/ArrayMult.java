package main;

public class ArrayMult {
	public int[] mult(int[] array1, int[] array2){
		
		int minlen = Math.min(array1.length, array2.length);

		//	LongArray = outArray
		int [] outArray = new int [Math.max(array1.length, array2.length)];
		
		for (int i = 0; i < minlen; i+=1){
			outArray[i] = array1[i] * array2[i];
		}
		
		for (int j = minlen; j < outArray.length; j+=1){
			if (array1.length > array2.length){
				outArray[j] = array1[j];				
			}
			else{
				outArray[j] = array2[j];
			}
		}
		return outArray;
	}
}
