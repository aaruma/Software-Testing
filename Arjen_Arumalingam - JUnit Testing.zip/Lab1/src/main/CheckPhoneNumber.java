package main;
import java.util.*;

public class CheckPhoneNumber {
	public static boolean isValidPhoneNumber(String s) {
		/* The "\d" is the number of digits used for the phone number.
		 * For example, \d{3} means three integer values. 
		 */
		//return s.matches("(\\d{3}) \\d{3} - \\d{4}");
		return s.matches("\\(\\d{3}\\)\\s*\\d{3}\\s*-\\s*\\d{4}"); 
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter a phone number: ");
		String input = sc.nextLine();
		boolean wasPhoneNum = isValidPhoneNumber(input);
		System.out.println("\nThat was"+(wasPhoneNum? "" : "n't")+" a phone number."); 
	}
}

