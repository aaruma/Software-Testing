package test;

import static org.junit.Assert.*;

import java.util.Arrays;
import main.PrimeNumberChecker;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(value = Parameterized.class)

public class PrimeNumberCheckerTest {
	private int numbers;
	private boolean result;
	
	public PrimeNumberCheckerTest (int numbers, boolean result) {
		this.numbers = numbers;
		this.result = result;
	}
	
	@Parameterized.Parameters()
	public static Iterable<Object[]> data(){
		return Arrays.asList(new Object[][]{
			{2, true}, {6, false}, {19, true}, {22, false}, {23, true}
		});
	}
	
	@Test
	public void test() {
		assertEquals(result, PrimeNumberChecker.checkPrime(numbers));
	}

}
