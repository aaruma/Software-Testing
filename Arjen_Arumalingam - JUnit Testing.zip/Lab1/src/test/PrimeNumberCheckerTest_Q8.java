package test;

import static org.junit.Assert.*;
import main.PrimeNumberChecker;

import org.junit.Test;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
public class PrimeNumberCheckerTest_Q8 {
	@DataPoints
	public static Object[][] values = new Object[][]{
		{2, true}, {6, false}, {19, true}, {22, false}, {23, true}
	};
	
	@Theory
	public void PrimeTest(Object[]x){
		boolean result = PrimeNumberChecker.checkPrime((Integer) x[0]);
		assertEquals(x[1], result);
	}

}
