package test;
import static org.junit.Assert.*;
import main.Triangle;

import org.junit.Before;
import org.junit.Test;

public class TriangleTest {
	
	private Triangle t1, t2, t3;
	
	@Before
	public void initialization(){
		t1 = new Triangle(3, 4, 5);
		t2 = new Triangle(5, 4, 3);
		t3 = new Triangle(8, 5, 5);
	}

	@Test
	public void test() {
		assertEquals(6.0, t1.calculateArea(), 0.0);
	}
	
	@Test
	public void test2() {
		assertEquals(6.0, t2.calculateArea(), 0.0);
	}
	
	@Test
	public void test3() {
		assertEquals(12.0, t3.calculateArea(), 0.0);
	}
	
	// Invalid Side
	@Test(expected=ArithmeticException.class)
	public void invalidTest(){
		Triangle newTriangle = new Triangle(3, 4, 100);
		newTriangle.calculateArea();
	
	}
	
	// Negative Sides
	@Test(expected=ArithmeticException.class)
	public void invalidTest2(){
		Triangle newTriangle = new Triangle(-3, 4, -100);
		newTriangle.calculateArea();
	
	}

}

