package test;

import static org.junit.Assert.*;

import org.junit.Assume;
import org.junit.Test;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
import static org.junit.Assume.assumeTrue;
import static org.junit.Assume.assumeNotNull;

@RunWith (Theories.class)
public class Q7Test {
	@DataPoints
	public static int [] val = new int[]{1,2,307,400567};
	
	@DataPoints
	public static int [] newval = new int[]{0, -1, -10, -1234, 1, 10, 6789};
	
	@DataPoints
	public static int [] anotherval = new int[]{0, -1, -10, -1234, 1, 10, 6789, Integer.MAX_VALUE, Integer.MIN_VALUE};
	
	// Mathematical Theory 
		@Theory
		public void testmathematicalTheory(int a, int b) {
			assumeNotNull(a, b);
			assumeTrue(a > 0 && b > 0);
			
			assumeTrue(a != Integer.MAX_VALUE && a != Integer.MIN_VALUE);
			assumeTrue(b != Integer.MAX_VALUE && b != Integer.MIN_VALUE);
			
			assertTrue(a + b > a);
			assertTrue(a + b > b);
		}
	
	// Commutative Theory
		@Theory
		public void testcommutativeTheory(int a, int b) throws Exception{
			assumeNotNull(a, b);
			assertTrue(a + b == b + a);			
		}
}
