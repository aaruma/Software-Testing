package test;
import static org.junit.Assert.*;
import main.ArrayMult;
import org.junit.Test;

public class ArrayMultTest {

	@Test
	public void test() {
		ArrayMult arrays = new ArrayMult();
		
		// Test 1
		int [] array1 = {5,8,2,0,3};
		int [] array2 = {1,2,5,8,11};
		int [] result1 = arrays.mult(array1, array2);
		assertArrayEquals(new int[] {5,16,10,0,33}, result1);
		
		// Test 2
		int [] array3 = {1};
		int [] array4 = {2,4,5,6};
		int [] result2 = arrays.mult(array3, array4);
		assertArrayEquals(new int[] {2,4,5,6}, result2);
		
		// Test 3
		int [] array5 = {2, 4, 6, 8};
		int [] array6 = {15, 10, 5, 4};
		int [] result3 = arrays.mult(array5, array6);
		assertArrayEquals(new int[] {30, 40, 30, 32}, result3);
	}
}
