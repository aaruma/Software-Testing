package test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import main.CheckPhoneNumber;
import org.junit.Test;

public class CheckPhoneNumberTest {

	@Test
	public void test() {
		assertTrue(CheckPhoneNumber.isValidPhoneNumber("(123) 456-7890"));
	}
	
	@Test
	public void test2() {
		assertTrue(CheckPhoneNumber.isValidPhoneNumber("(123)123-1234"));
	}
	
	@Test
	public void test3() {
		assertFalse(CheckPhoneNumber.isValidPhoneNumber("123 123-1234"));
	}
	
	
	public void testCheckPhoneNumber() {
	
	    boolean test1 = CheckPhoneNumber.isValidPhoneNumber("(123) 456 -7890");
	    boolean test2 = CheckPhoneNumber.isValidPhoneNumber("(123) 456-7890");
	    boolean test3 = CheckPhoneNumber.isValidPhoneNumber("(123)456- 7890");   
	    boolean test4 = CheckPhoneNumber.isValidPhoneNumber("(123)    456    -    7890");
	    boolean test5 = CheckPhoneNumber.isValidPhoneNumber("(123)    456-7890");
	              
        assertTrue(test1);
        assertTrue(test2);
        assertTrue(test3);
        assertTrue(test4);
        assertTrue(test5);
     
    }
	    
	    @Test
	    public void testInvalidPhoneNumber() {
	       
	        boolean test1 = CheckPhoneNumber.isValidPhoneNumber("123 456  7890");
	        boolean test2 = CheckPhoneNumber.isValidPhoneNumber("123456 - 7890");
	        boolean test3 = CheckPhoneNumber.isValidPhoneNumber("1S3 456 - 7890");
	        
	        assertFalse(test1);
	        assertFalse(test2);
	        assertFalse(test3);
	 
	    }
	
	
	
}
