
public class Student {
	public String displayStudentName(String firstName, String lastName) {
		return firstName + lastName;
	}
}
