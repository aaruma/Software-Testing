package test;

//package ;

import main.IMoney;
import main.Money;
import main.MoneyBag;

import org.junit.Test;

import junit.framework.TestCase;


public class MoneyBagTest extends TestCase {
    private Money f12CHF;
    private Money f14CHF;
    private Money f7USD;
    private Money f21USD;

    private IMoney fMB1;
    private IMoney fMB2;

    public static void main(String args[]) {
        junit.textui.TestRunner.run(MoneyBagTest.class);
    }

    protected void setUp() {
        f12CHF = new Money(12, "CHF");
        f14CHF = new Money(14, "CHF");
        f7USD = new Money(7, "USD");
        f21USD = new Money(21, "USD");

        fMB1 = MoneyBag.create(f12CHF, f7USD);
        fMB2 = MoneyBag.create(f14CHF, f21USD);
    }

    protected void tearDown() throws Exception {
        // call toString, guranteed to be only called from here.
        // this is for testing, coverage by test.
        fMB1.toString();
    }

    public void testBagMultiply() {
        // {[12 CHF][7 USD]} *2 == {[24 CHF][14 USD]}
        IMoney expected = MoneyBag.create(new Money(24, "CHF"), new Money(14, "USD"));
        assertEquals(expected, fMB1.multiply(2));
        assertEquals(fMB1, fMB1.multiply(1));
        assertTrue(fMB1.multiply(0).isZero());
    }

    public void testBagNegate() {
        // {[12 CHF][7 USD]} negate == {[-12 CHF][-7 USD]}
        IMoney expected = MoneyBag.create(new Money(-12, "CHF"), new Money(-7, "USD"));
        assertEquals(expected, fMB1.negate());
    }

    public void testBagSimpleAdd() {
        // {[12 CHF][7 USD]} + [14 CHF] == {[26 CHF][7 USD]}
        IMoney expected = MoneyBag.create(new Money(26, "CHF"), new Money(7, "USD"));
        assertEquals(expected, fMB1.add(f14CHF));
    }

    public void testBagSubtract() {
        // {[12 CHF][7 USD]} - {[14 CHF][21 USD] == {[-2 CHF][-14 USD]}
        IMoney expected = MoneyBag.create(new Money(-2, "CHF"), new Money(-14, "USD"));
        assertEquals(expected, fMB1.subtract(fMB2));
    }

    public void testBagSumAdd() {
        // {[12 CHF][7 USD]} + {[14 CHF][21 USD]} == {[26 CHF][28 USD]}
        IMoney expected = MoneyBag.create(new Money(26, "CHF"), new Money(28, "USD"));
        assertEquals(expected, fMB1.add(fMB2));
    }

    public void testIsZero() {
        assertTrue(fMB1.subtract(fMB1).isZero());
        assertTrue(MoneyBag.create(new Money(0, "CHF"), new Money(0, "USD")).isZero());
    }
    
//    Added Begins
    
    public void testZero() {
        Money try0 = new Money(0, "USD");
        IMoney try1 = new Money(0, "USD");
        
        assertTrue(try0.equals(try1));
        assertEquals("USD", try0.currency());
    }
    
    public void testNotValidObjectEquals() {
    	Object anObj = new Object();
        IMoney moneyTest = new Money(0, "EURO");
        
        assertEquals(false, moneyTest.equals(anObj));
   }
    
    public void testEqualsWithZeroBags() {
        MoneyBag emptyBag1 = new MoneyBag();
        MoneyBag emptyBag2 = new MoneyBag();

        assertTrue(emptyBag1.equals(emptyBag2));
    }
    
    public void testNotValidObjectInBagEquals() {
    	 Object anObj = new Object();
    	 MoneyBag moneyBagTest = new MoneyBag();
         
         assertEquals(false, moneyBagTest.equals(anObj));
    }
    
    public void testEqualsWithUnequalBagLengths() {
    	MoneyBag bag1Size2 = (MoneyBag) MoneyBag.create(new Money(10, "USD"), new Money(10, "CHF"));
        
    	MoneyBag bag2Size2 = (MoneyBag) MoneyBag.create(new Money(10, "USD"), new Money(10, "CHF"));
    	MoneyBag bag3Size2 = (MoneyBag) MoneyBag.create(new Money(10, "EURO"), new Money(10, "INR"));
        
        bag2Size2 = (MoneyBag) bag2Size2.addMoneyBag(bag3Size2);      

        assertFalse(bag1Size2.equals(bag2Size2));
    }
//    Added Ends

    public void testMixedSimpleAdd() {
        // [12 CHF] + [7 USD] == {[12 CHF][7 USD]}
        IMoney expected = MoneyBag.create(f12CHF, f7USD);
        assertEquals(expected, f12CHF.add(f7USD));
    }

    public void testBagNotEquals() {
        IMoney bag = MoneyBag.create(f12CHF, f7USD);
        assertFalse(bag.equals(new Money(12, "DEM").add(f7USD)));
    }

    public void testMoneyBagEquals() {
        assertTrue(!fMB1.equals(null));

        assertEquals(fMB1, fMB1);
        IMoney equal = MoneyBag.create(new Money(12, "CHF"), new Money(7, "USD"));
        assertTrue(fMB1.equals(equal));
        assertTrue(!fMB1.equals(f12CHF));
        assertTrue(!f12CHF.equals(fMB1));
        assertTrue(!fMB1.equals(fMB2));
    }

    public void testMoneyBagHash() {
        IMoney equal = MoneyBag.create(new Money(12, "CHF"), new Money(7, "USD"));
        assertEquals(fMB1.hashCode(), equal.hashCode());
    }

    public void testMoneyEquals() {
        assertTrue(!f12CHF.equals(null));
        Money equalMoney = new Money(12, "CHF");
        assertEquals(f12CHF, f12CHF);
        assertEquals(f12CHF, equalMoney);
        assertEquals(f12CHF.hashCode(), equalMoney.hashCode());
        assertTrue(!f12CHF.equals(f14CHF));
    }

    public void testMoneyHash() {
        assertTrue(!f12CHF.equals(null));
        Money equal = new Money(12, "CHF");
        assertEquals(f12CHF.hashCode(), equal.hashCode());
    }

    public void testSimplify() {
        IMoney money = MoneyBag.create(new Money(26, "CHF"), new Money(28, "CHF"));
        assertEquals(new Money(54, "CHF"), money);
    }

    public void testNormalize2() {
        // {[12 CHF][7 USD]} - [12 CHF] == [7 USD]
        Money expected = new Money(7, "USD");
        assertEquals(expected, fMB1.subtract(f12CHF));
    }

    public void testNormalize3() {
        // {[12 CHF][7 USD]} - {[12 CHF][3 USD]} == [4 USD]
        IMoney ms1 = MoneyBag.create(new Money(12, "CHF"), new Money(3, "USD"));
        Money expected = new Money(4, "USD");
        assertEquals(expected, fMB1.subtract(ms1));
    }

    public void testNormalize4() {
        // [12 CHF] - {[12 CHF][3 USD]} == [-3 USD]
        IMoney ms1 = MoneyBag.create(new Money(12, "CHF"), new Money(3, "USD"));
        Money expected = new Money(-3, "USD");
        assertEquals(expected, f12CHF.subtract(ms1));
    }

    public void testPrint() {
        assertEquals("[12 CHF]", f12CHF.toString());
    }

    public void testSimpleAdd() {
        // [12 CHF] + [14 CHF] == [26 CHF]
        Money expected = new Money(26, "CHF");
        assertEquals(expected, f12CHF.add(f14CHF));
    }

    public void testSimpleBagAdd() {
        // [14 CHF] + {[12 CHF][7 USD]} == {[26 CHF][7 USD]}
        IMoney expected = MoneyBag.create(new Money(26, "CHF"), new Money(7, "USD"));
        assertEquals(expected, f14CHF.add(fMB1));
    }

    public void testSimpleMultiply() {
        // [14 CHF] *2 == [28 CHF]
        Money expected = new Money(28, "CHF");
        assertEquals(expected, f14CHF.multiply(2));
    }

    public void testSimpleNegate() {
        // [14 CHF] negate == [-14 CHF]
        Money expected = new Money(-14, "CHF");
        assertEquals(expected, f14CHF.negate());
    }

    public void testSimpleSubtract() {
        // [14 CHF] - [12 CHF] == [2 CHF]
        Money expected = new Money(2, "CHF");
        assertEquals(expected, f14CHF.subtract(f12CHF));
    }
    
    @Test
    public void testMoneyBagEqualsWithDifferentMoneys() {
        MoneyBag mb1 = (MoneyBag) MoneyBag.create(new Money(10, "USD"), new Money(20, "EUR"));
        MoneyBag mb2 = (MoneyBag) MoneyBag.create(new Money(10, "USD"), new Money(30, "EUR"));
        assertFalse(mb1.equals(mb2));
    }

    @Test
    public void testMoneyBagEqualsWithEmptyBag() {
        MoneyBag mb1 = (MoneyBag) MoneyBag.create(new Money(10, "USD"), new Money(20, "EUR"));
        MoneyBag emptyBag = new MoneyBag();
        assertFalse(mb1.equals(emptyBag));
    }
    
    @Test
    public void testMoneyBagEqualsWithSelf() {
        MoneyBag mb = (MoneyBag) MoneyBag.create(new Money(10, "USD"), new Money(20, "EUR"));
        assertTrue(mb.equals(mb));
    }
    
//    @Test
//    public void testMoneyBagHashCodeWithSingleMoney() {
//        MoneyBag mb = MoneyBag.create(new Money(10, "USD"));
//        int expectedHashCode = new Money(10, "USD").hashCode();
//        assertEquals(expectedHashCode, mb.hashCode());
//    }

    
    @Test
    public void testMoneyBagHashCodeWithMultipleMoneys() {
        MoneyBag mb = (MoneyBag) MoneyBag.create(new Money(10, "USD"), new Money(20, "EUR"));
        int expectedHashCode = new Money(10, "USD").hashCode() ^ new Money(20, "EUR").hashCode();
        assertEquals(expectedHashCode, mb.hashCode());
    }
    
    @Test
    public void testMoneyBagToStringWithEmptyBag() {
        MoneyBag emptyBag = new MoneyBag();
        assertEquals("{}", emptyBag.toString());
    }


    @Test
    public void testMoneyBagToStringWithSingleMoney() {
        MoneyBag mb = new MoneyBag();
        mb.appendMoney(new Money(10, "USD"));
        assertEquals("{[10 USD]}", mb.toString());
    }

    @Test
    public void testMoneyBagToStringWithMultipleMoneys() {
        MoneyBag mb = new MoneyBag();
        mb.appendMoney(new Money(10, "USD"));
        mb.appendMoney(new Money(20, "EUR"));
        assertEquals("{[10 USD][20 EUR]}", mb.toString());
    }
    
}