package test;

//package ;

import main.IMoney;
import main.Money;
import main.MoneyBag;

import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

import junit.framework.TestCase;

/**
 * This is a trivial test which only tests the Money class.
 * If you modify the MoneyBag class, and run Clover with optimization, this test will not be run.
 */
public class MoneyTest extends TestCase {

	@Test
    public void testAdd() throws InterruptedException {
        Money tenEuro = new Money(10, "EURO");
        assertEquals(10, tenEuro.amount());
        assertEquals("EURO", tenEuro.currency());
        System.out.println("Tests taking too long? Try Clover's test optimization.");
        Thread.sleep(3000);
    }
    
    @Test
    public void testEqualityCheck() throws InterruptedException {
        Money zeroRiyal1 = new Money(0, "SAR");
        IMoney zeroRiyal2 = new Money(0, "SAR");
        assertEquals(true, zeroRiyal1.equals(zeroRiyal2));
        assertEquals("SAR", zeroRiyal1.currency());
        System.out.println("Tests taking too long? Try Clover's test optimization.");
        Thread.sleep(3000);
    }
    
    @Test
    public void testEqualsWithDifferentAmounts() {
        Money m1 = new Money(10, "USD");
        Money m2 = new Money(20, "USD");
        assertFalse(m1.equals(m2));
    }

    @Test
    public void testEqualsWithDifferentCurrencies() {
        Money m1 = new Money(10, "USD");
        Money m2 = new Money(10, "EUR");
        assertFalse(m1.equals(m2));
    }

    @Test
    public void testEqualsWithZero() {
        Money m1 = new Money(0, "USD");
        Money m2 = new Money(10, "USD");
        assertFalse(m1.equals(m2));
    }
    
    @Test
    public void testHashCodeWithDifferentAmounts() {
        Money m1 = new Money(10, "USD");
        Money m2 = new Money(20, "USD");
        assertNotEquals(m1.hashCode(), m2.hashCode());
    }

    @Test
    public void testHashCodeWithDifferentCurrencies() {
        Money m1 = new Money(10, "USD");
        Money m2 = new Money(10, "EUR");
        assertNotEquals(m1.hashCode(), m2.hashCode());
    }
    
    @Test
    public void testAddition() {
        Money m1 = new Money(10, "USD");
        Money m2 = new Money(20, "USD");
        Money expected = new Money(30, "USD");
        assertEquals(expected, m1.add(m2));
    }

    @Test
    public void testMultiplication() {
        Money m1 = new Money(10, "USD");
        Money expected = new Money(50, "USD");
        assertEquals(expected, m1.multiply(5));
    }
    
    @Test
    public void testAdditionWithDifferentCurrencies() {
        Money m1 = new Money(10, "USD");
        Money m2 = new Money(20, "EUR");
        MoneyBag expected = (MoneyBag) MoneyBag.create(new Money(10, "USD"), new Money(20, "EUR"));
        assertEquals(expected, m1.add(m2));
    }
    
    
    
}
