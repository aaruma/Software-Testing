package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class q5_functionswithpriorityPT2 {
	
	  private WebDriver driver;

	    @BeforeTest
	    public void openBrowser() {
	    		// System.setProperty("webdriver.gecko.driver", "path/to/geckodriver");
	            driver = new FirefoxDriver();
	    }

	    @Test(priority = 0)
	    public void launchGoogle() {
	        // Launch "http://www.google.com"
	        driver.get("http://www.google.com");
	    }

	    @Test(priority = 1)
	    public void peformSeachAndClick1stLink() {
	        // Perform a search using "Facebook" through Google search field
	        WebElement searchBox = driver.findElement(By.xpath(".//*[@title='Search']"));
	        searchBox.sendKeys("Facebook");
	        searchBox.submit();
	        
	        // Wait for a moment to simulate some processing
	        try {
	            Thread.sleep(2000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	       
	        // Click on the first search result link
	        //WebElement firstLink = driver.findElement(By.xpath("//h3[contains(text(),'Facebook')]"));
	        //firstLink.click();
	    }

	    @Test (priority = 2)
	    public void FaceBookPageTitleVerification() {
	    	
	        // Verify the title of Google search page
	        Assert.assertEquals(driver.getTitle(), "Facebook - Google Search");

	        // Retrieve and test the title of the search result page
	        String searchResultPageTitle = driver.getTitle();
	        Assert.assertTrue(searchResultPageTitle.contains("Facebook"), "Search result page title doesn't contain 'Facebook'");
		}

	    @AfterTest
	    public void driverExit() {
	    	driver.quit();
	
	    }
	}
