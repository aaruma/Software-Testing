package test;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

public class q3_FacebookTag {
	
	// System.setProperty("webdriver.gecko.driver", "C:\\geckodriver.exe");
	@Test
	public void getTag(){
		
        WebDriver driver = new FirefoxDriver();

        driver.get("http://www.facebook.com");

        // Locate the email text-field element by name attribute
        WebElement email = driver.findElement(By.name("email"));

        // Retrieve the tag name of the email text field
        String tag = email.getTagName();
        System.out.println("Tag Name of Email Text Field: " + tag);
        
        // Assert.assertEquals(actual, expected);
        Assert.assertEquals(tag, "input");
        driver.quit();
    }
}
