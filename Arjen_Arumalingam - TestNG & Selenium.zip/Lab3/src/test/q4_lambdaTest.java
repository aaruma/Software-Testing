package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class q4_lambdaTest {
	  
		private WebDriver driver;

	    @BeforeTest
	    public void setup() {
	        // Set the path to the gekoDriver executable
	    	// System.setProperty("webdriver.gecko.driver", "C:\\geckodriver.exe");

	        // Create a new instance of the FirefoxDriver
	        driver = new FirefoxDriver();

	        // Navigate to website
	        driver.get("https://lambdatest.github.io/sample-todo-app/");
	    }

	    @Test
	    public void testTodoApp() {
	        // Find and mark the "Second Item" 
	        WebElement secondItemCheckbox = driver.findElement(By.name("li1"));
	        secondItemCheckbox.click();

	        // Find and mark the "Fourth Item"
	        WebElement fourthItemCheckbox = driver.findElement(By.name("li3"));
	        fourthItemCheckbox.click();

	        // Find the empty text field at the end, clear the content, and add "Arjen"
	        WebElement textField = driver.findElement(By.id("sampletodotext"));
	        textField.clear();
	        textField.sendKeys("Arjen");

	        // Submit form
	        WebElement addButton = driver.findElement(By.id("addbutton"));
	        addButton.click();
	    }

//	    @AfterTest
//	    public void tearDown() {
//	        // Close the browser
//	        driver.quit();
//	    }
}
 