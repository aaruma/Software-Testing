package test;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

public class q2_WebpageTitle {
	
	// System.setProperty("webdriver.gecko.driver", "C:\\geckodriver.exe");
	@Test
	public void getTitle()
    {
	    WebDriver driver = new FirefoxDriver();

        driver.get("http://demo.guru99.com/test/newtours/");
        String pageTitle = driver.getTitle();
        System.out.println("Page Title: " + pageTitle);

        Assert.assertEquals(pageTitle, "Welcome: Mercury Tours", "Page title does not match.");
       
        driver.quit();
    }
}