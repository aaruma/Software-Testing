package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class q6_ParallelTesting {

    private WebDriver driver1;
    private WebDriver driver2;
    private WebDriver driver3;

    @Test
    public void executSessionOne() {
    	 // System.setProperty("webdriver.gecko.driver", "path/to/geckodriver");
        driver1 = new FirefoxDriver();

        // Navigate to website
        driver1.get("http://demo.guru99.com/V4/");
    	
        // Find the element UserID and fill it with "Driver 1"
        WebElement userIdField = driver1.findElement(By.name("uid"));
        userIdField.sendKeys("Driver 1");
        //driver1.close();
    }

    @Test
    public void executSessionTwo() {
    	 // System.setProperty("webdriver.gecko.driver", "path/to/geckodriver");
        driver2 = new FirefoxDriver();

        // Navigate to website
        driver2.get("http://demo.guru99.com/V4/");
    	
        // Find the element UserID and fill it with "Driver 2"
        WebElement userIdField = driver2.findElement(By.name("uid"));
        userIdField.sendKeys("Driver 2");
        //driver2.close();
    }

    @Test
    public void executSessionThree() {
    	 // System.setProperty("webdriver.gecko.driver", "path/to/geckodriver");
        driver3 = new FirefoxDriver();

        // Navigate to website
        driver3.get("http://demo.guru99.com/V4/");
    	
        // Find the element UserID and fill it with "Driver 3"
        WebElement userIdField = driver3.findElement(By.name("uid"));
        userIdField.sendKeys("Driver 3");
        //driver3.close();
    }
    
}