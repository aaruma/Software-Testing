package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class q7_Linkedin {
    
	private WebDriver driver;	

    @BeforeTest
    public void setup() {
        //System.setProperty("webdriver.gecko.driver", "path/to/geckodriver");
        
    	// Create a new instance of the FirefoxDriver
        driver = new FirefoxDriver();
        // Navigate to the LinkedIn login page
        driver.get("https://www.linkedin.com/login");
    }

    @Test
    public void loginToLinkedIn() {
        // Find username, password, and login button elements
        WebElement usernameField = driver.findElement(By.id("username"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.xpath("//button[@type='submit']"));

        // Enter your LinkedIn credentials
        usernameField.sendKeys("Username");
        passwordField.sendKeys("Password");

        // Click on login button
        loginButton.click();

        // Add a delay to see the interaction
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Verify the current URL after login
        String actualUrl = driver.getCurrentUrl();
        String expectedUrl = "https://www.linkedin.com/feed/";
        Assert.assertEquals(actualUrl, expectedUrl, "Login unsuccessful");

        System.out.println("Login successful! Current URL: " + actualUrl);
    }

    @AfterTest
    public void tearDown() {
    	driver.quit();
    }
}