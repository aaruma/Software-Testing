package test;

import static org.junit.Assert.*;
import main.Q2_Palindrome;
import main.Q3_computestat;

import org.junit.Test;

public class Q3_computestatTest {

	@Test(expected = NullPointerException.class)
    public void testNullString() {
		Q3_computestat.computeStats(null);
    }
	
	@Test
    public void testval() {
        Q3_computestat.computeStats(new int [] {1,2,3});
    }
	
	@Test(expected = IndexOutOfBoundsException.class)
    public void testEmpty() {
        Q3_computestat.computeStats(new int [] {});
    }
}
