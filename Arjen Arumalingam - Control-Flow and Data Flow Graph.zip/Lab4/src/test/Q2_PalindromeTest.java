package test;

import static org.junit.Assert.*;
import main.Q2_Palindrome;

import org.junit.Test;

public class Q2_PalindromeTest {

	@Test(expected = NullPointerException.class)
    public void testNullString() {
		Q2_Palindrome.isPalindrome(null);
    }
	
	@Test
    public void testEmpty() {
        assertTrue(Q2_Palindrome.isPalindrome(""));
    }

    @Test
    public void testSingleNodeCoverage() {
        assertTrue(Q2_Palindrome.isPalindrome("a"));
    }

    @Test
    public void testEdgeCoverage() {
        assertFalse(Q2_Palindrome.isPalindrome("ab"));
    }

    @Test
    public void testEdgePairCoverage() {
        assertTrue(Q2_Palindrome.isPalindrome("aba"));
    }
}

