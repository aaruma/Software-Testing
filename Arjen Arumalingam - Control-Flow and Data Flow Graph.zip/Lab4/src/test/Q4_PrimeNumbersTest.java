package test;

import static org.junit.Assert.*;
import main.Q4_PrimeNumbers;

import org.junit.Test;

public class Q4_PrimeNumbersTest {

	@Test
	public void test() {
		Q4_PrimeNumbers.printPrimes(10);
	}
	
	@Test
	public void test2() {
		Q4_PrimeNumbers.printPrimes(0);
	}
	
	@Test
	public void test3() {
		Q4_PrimeNumbers.printPrimes(-6);
	}

}
